  (function () {
      const form = document.getElementById('regForm');
      const toast = document.getElementById('toast');

      const setValidity = (fieldEl, isValid) => {
        fieldEl.classList.toggle('invalid', !isValid);
      };


      form.querySelectorAll('.field').forEach(field => {
        const input = field.querySelector('.control');
        input.addEventListener('blur', () => setValidity(field, input.checkValidity()));
        input.addEventListener('input', () => setValidity(field, input.checkValidity()));
      });

      form.addEventListener('submit', (e) => {
        e.preventDefault();
        let allValid = true;
        form.querySelectorAll('.field').forEach(field => {
          const input = field.querySelector('.control');
          const valid = input.checkValidity();
          setValidity(field, valid);
          if (!valid) allValid = false;
        });

        if (!allValid) {

          const firstInvalid = form.querySelector('.field.invalid .control');
          if (firstInvalid) firstInvalid.focus();
          return;
        }


        toast.textContent = 'Registered';
        toast.classList.add('show');
        setTimeout(() => toast.classList.remove('show'), 2200);


        form.reset();
      });

      form.addEventListener('reset', () => {
        form.querySelectorAll('.field.invalid').forEach(f => f.classList.remove('invalid'));
      });
    })();